from BLE_CEEO import Yell, Listen
import time
import network, ubinascii
import mqtt
import machine

wifi = {'ssid':'tufts_eecs','pass':'foundedin1883'}

def connect_wifi(wifi):
    station = network.WLAN(network.STA_IF)
    station.active(True)
    mac = ubinascii.hexlify(network.WLAN().config('mac'), ':').decode()
    print("MAC " + mac)
    station.connect(wifi['ssid'], wifi['pass'])
    while not station.isconnected():
        time.sleep(1)
    print('Connection successful')
    print(station.ifconfig())

connect_wifi(wifi)

def whenCalled(topic, msg):
    message = (topic.decode(), msg.decode())
    message = message[1]
    topic_string = topic.decode('utf-8')
    #print(topic_string)
    
    if topic_string == 'LEGO/rc_car':
        control_values = message.split(".")
        control_values = control_values[0] + "."    
        p.send(control_values)
    if topic_string == 'polkm':
        p.send(message)

p = Yell('steve', verbose = True)

if p.connect_up():
    print('P connected')
    time.sleep(2)

try:
    fred = mqtt.MQTTClient('Car', 'broker.hivemq.com', keepalive=1000)
    temp = fred.connect()
    print('MQTT Connected')
    fred.set_callback(whenCalled)
    fred.subscribe('LEGO/rc_car')
    fred.subscribe('polkm')
    #fred.publish('LEGO/rc_car', 'started')  

    while True:
        
        temp = fred.wait_msg()  # check subscriptions - you might want to do this more often
        
        if p.is_any:
            message = p.read()
            message = str(message.split(",")[0])
            #print(message)
            #fred.publish('LEGO/pico_test', message)
        if not p.is_connected:
            print('lost connection')
            break
        
        time.sleep_ms(100)

except Exception as e:
    print(e)
finally: 
    fred.disconnect()
    print('MQTT Disconnected')