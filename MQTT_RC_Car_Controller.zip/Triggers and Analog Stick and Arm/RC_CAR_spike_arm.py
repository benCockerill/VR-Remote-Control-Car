from BLE_CEEO import Yell, Listen
import time
from hub import port
import motor

def central(name):
    
    try:
        L = Listen(name, verbose=True)
        if L.connect_up():
            print('L connected')
            while L.is_connected:
                time.sleep_ms(100)  # Adjust sleep time as needed
                
                if L.is_any:
                    message = L.read()
                    
                    if '[' not in message:
                        control_values = message.split(".")[0]
                        control_values = control_values.split(",")
                        if len(control_values) == 3:
                            throttle = (-1) * int(control_values[0])
                            x = int(control_values[1])
                            camera_pos = int(control_values[2])
                            #print(control_values)
                            steer_angle = int(90 - ((x - 132)*(30/132)))
                            motor.run(port.A, throttle)
                            motor.run_to_absolute_position(port.B, steer_angle, 200)
                            motor.run_to_absolute_position(port.C, camera_pos, 200)
                    else:
                        arm_values = message.replace('[', '').replace(']', '')
                        arm_values = arm_values.split(",")
                        #print(arm_values)
                        
                        #LIFT
                        if arm_values[0] == "T":
                            motor.run(port.F, -100)
                        elif arm_values[1] == "T":
                            motor.run(port.F, 100)
                        else:
                            motor.stop(port.F)
                        
                        #PAN
                        if arm_values[2] == "T":
                            motor.run(port.E, -70)
                        elif arm_values[3] == "T":
                            motor.run(port.E, 70)
                        else:
                            motor.stop(port.E)
                        
                        #CLAW
                        if arm_values[4] == "T":
                            motor.run(port.D, 1000)
                        elif arm_values[5] == "T":
                            motor.run(port.D, -1000)
                        else:
                            motor.stop(port.D)
                    
    
    except Exception as e:
        print(e)
    finally:
        L.disconnect()
        print('Closing up')

central('steve')
