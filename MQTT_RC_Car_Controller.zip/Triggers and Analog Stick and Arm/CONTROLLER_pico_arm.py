from BLE_CEEO import Yell, Listen
import time
import network, ubinascii
import mqtt
import machine

wifi = {'ssid':'tufts_eecs','pass':'foundedin1883'}

def connect_wifi(wifi):
    station = network.WLAN(network.STA_IF)
    station.active(True)
    mac = ubinascii.hexlify(network.WLAN().config('mac'), ':').decode()
    print("MAC " + mac)
    station.connect(wifi['ssid'], wifi['pass'])
    while not station.isconnected():
        time.sleep(1)
    print('Connection successful')
    print(station.ifconfig())

def whenCalled(topic, msg):
    print((topic.decode(), msg.decode()))
    
def read_joystick_position():
    try:
        # Send command to read X axis
        i2c.writeto(I2C_ADDRESS, bytes([X_AXIS_REG]))
        x_val = i2c.readfrom(I2C_ADDRESS, 1)[0]

        # Send command to read Y axis
        i2c.writeto(I2C_ADDRESS, bytes([Y_AXIS_REG]))
        y_val = i2c.readfrom(I2C_ADDRESS, 1)[0]

        return x_val, y_val
    except OSError as e:
        print(f"OSError: {e}")
        return None, None

# Connect to wifi network
connect_wifi(wifi)

# Constants for I2C
I2C_ADDRESS = 0x20  # Default I2C address of Qwiic Joystick

# Register addresses
X_AXIS_REG = 0x03
Y_AXIS_REG = 0x05

# Initialize I2C
i2c = machine.I2C(1, scl=machine.Pin(3), sda=machine.Pin(2), freq=400000)

# Initialize bluetooth
p = Yell('bob', verbose = True)
        
if p.connect_up():
    print('P connected')
    time.sleep(2)

# Initialize MQTT
try:
    fred = mqtt.MQTTClient('Controller', 'broker.hivemq.com', keepalive=1000)
    temp = fred.connect()
    print('MQTT Connected')
    fred.set_callback(whenCalled)
    fred.subscribe('LEGO/rc_car')
    fred.publish('LEGO/rc_car', 'started')  

    while True:
        
        x, y = read_joystick_position()
        str_x = str(x)
        #str_y = str(y)
        
        if p.is_any:
            controller_values = p.read()
            controller_values = controller_values.split(".")[0]
            controller_values = controller_values.split(",")
            throttle = controller_values[0]
            camera_pos = controller_values[1]
            #print(message)
            temp = fred.wait_msg()  # check subscriptions - you might want to do this more often
            fred.publish('LEGO/rc_car', throttle+","+str_x+","+camera_pos+".")
        if not p.is_connected:
            print('lost connection')
            break
        
        time.sleep_ms(100)

except Exception as e:
    print(e)
finally: 
    fred.disconnect()
    print('MQTT Disconnected')